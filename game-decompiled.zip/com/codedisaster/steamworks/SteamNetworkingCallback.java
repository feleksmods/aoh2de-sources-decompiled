package com.codedisaster.steamworks;

import com.codedisaster.steamworks.SteamID;
import com.codedisaster.steamworks.SteamNetworking;

public interface SteamNetworkingCallback {
    public void onP2PSessionConnectFail(SteamID var1, SteamNetworking.P2PSessionError var2);

    public void onP2PSessionRequest(SteamID var1);
}
