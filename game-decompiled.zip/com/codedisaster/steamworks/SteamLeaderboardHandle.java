package com.codedisaster.steamworks;

import com.codedisaster.steamworks.SteamNativeHandle;

public class SteamLeaderboardHandle
extends SteamNativeHandle {
    SteamLeaderboardHandle(long handle) {
        super(handle);
    }
}
