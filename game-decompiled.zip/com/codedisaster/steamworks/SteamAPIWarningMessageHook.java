package com.codedisaster.steamworks;

public interface SteamAPIWarningMessageHook {
    public void onWarningMessage(int var1, String var2);
}
