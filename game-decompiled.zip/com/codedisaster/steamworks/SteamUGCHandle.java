package com.codedisaster.steamworks;

import com.codedisaster.steamworks.SteamNativeHandle;

public class SteamUGCHandle
extends SteamNativeHandle {
    public SteamUGCHandle(long handle) {
        super(handle);
    }
}
