package com.badlogic.gdx.graphics.g3d.particles.renderers;

import com.badlogic.gdx.graphics.g3d.particles.ParallelArray;
import com.badlogic.gdx.graphics.g3d.particles.renderers.ParticleControllerRenderData;

public class BillboardControllerRenderData
extends ParticleControllerRenderData {
    public ParallelArray.FloatChannel regionChannel;
    public ParallelArray.FloatChannel colorChannel;
    public ParallelArray.FloatChannel scaleChannel;
    public ParallelArray.FloatChannel rotationChannel;
}
